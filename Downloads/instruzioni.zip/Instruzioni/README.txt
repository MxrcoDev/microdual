
IN ALLEGATO, MANULE DI ISTRUZIONI MICRO DUAL.


 _______________________ SEZIONE SUPPORTO ________________________
|                                                                 |
| Per ricevere supporto una volta effettuato l'acquisto,          |
| si prega di contattare lo staff tramite la seguente e-mail:     |
| # applicazioni@microdual.tk                                     |
|_________________________________________________________________|


 _____________________ SEZIONE SVILUPPATORI ______________________
|                                                                 |
| Per entrare a far parte del progetto di sviluppo MicroGadget,   |
| si prega di contattare lo staff tramite la seguente e-mail:     |
| # applicazioni@microdual.tk                                     |
|_________________________________________________________________|